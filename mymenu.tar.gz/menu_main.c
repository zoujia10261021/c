/**************************************************************************************************/
/* Copyright (C) zoujia, SSE@USTC, 2014-2015                                                      */
/*                                                                                                */
/*  FILE NAME             :  menu_main.c                                                          */
/*  PRINCIPAL AUTHOR      :  Zoujia                                                               */
/*  SUBSYSTEM NAME        :  menu_main                                                            */
/*  MODULE NAME           :  menu_main                                                            */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/20                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zoujia, 2014/09/20
 *
 */
#include<stdio.h>
#include<stdlib.h>
#include "menu_operate.h"







main()
{
    InitNes();
    char ch;
    int i = 0;
    printf("press 'a' to add your cmd\npress 's' to show your cmd\npress 'd' to delete your cmd\npress 'o' to leave the program\n");
    while(scanf("%c",&ch) == 1)
    {
        ++ i;
        switch (ch)
        {
            case 'a':
                AddCmd();
                printf("\n");
                break;
            case 's':
                MenuStart();
                printf("\n");
                break;
            case 'd':
                DeleteCmd();
                printf("\n");
                break;
            case 'o':
                break;
        }
        if(ch == 'o')
        {
            printf("Thanks for you to use our program\n");
            break;
        }
        if(i % 2 == 0)
        {
            printf("press 'a' to add your cmd\npress 's' to show your cmd\npress 'd' to delete your cmd\npress 'o' to leave the program\n");
        }	
    }   
}