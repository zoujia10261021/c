/**************************************************************************************************/
/* Copyright (C) zoujia, SSE@USTC, 2014-2015                                                      */
/*                                                                                                */
/*  FILE NAME             :  zoujia_menu_main.c                                                   */
/*  PRINCIPAL AUTHOR      :  Zoujia                                                               */
/*  SUBSYSTEM NAME        :  zoujia_menu_main                                                     */
/*  MODULE NAME           :  zoujia_menu_main                                                     */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/20                                                           */
/*  DESCRIPTION           :  This is a interface of support                                       */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zoujia, 2014/09/20
 *
 */
 
void InitLinkTable();
 
void InitCmdList();

int Help();

tDataNode * InitDataNode();

tLinkTableNode * CheckCmd(char* cmd,tLinkTable* pLinkTable);

int ShowAllCmd();
tDataNode* FindCmd(char *cmd);