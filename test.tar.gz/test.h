tLinkTableNode * GetLinkTableHead(tLinkTable * pLinkTable);

void AddLinkTableNode(tLinkTable * pLinkTable,tLinkTableNode * pLinkTableNode);


void DelLinkTableNode(tLinkTable * pLinkTable,tLinkTableNode * pLinkTableNode);

tDataNode * FindCmd(char * cmd);

tDataNode * InitDataNode();

void InitLinkTable();

void InitCmdList();

tLinkTableNode *  CheckCmd_Add(char * cmd,tLinkTable * pLinkTable);


/* This function is DeleteCmd()'s teststub*/
tLinkTableNode *  CheckCmd_Delete(char * cmd,tLinkTable * pLinkTable);