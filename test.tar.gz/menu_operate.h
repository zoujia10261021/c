    	
/**************************************************************************************************/
/* Copyright (C) zoujia, SSE@USTC, 2014-2015                                                      */
/*                                                                                                */
/*  FILE NAME             :  menu_operate.h                                                       */
/*  PRINCIPAL AUTHOR      :  zoujia                                                               */
/*  SUBSYSTEM NAME        :  menu_operate                                                         */
/*  MODULE NAME           :  menu_operate                                                         */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/16                                                           */
/*  DESCRIPTION           :  This is a interface of menu_operate                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by zoujia, 2014/09/16
 *
 */


/*
 *you can add or remove any attributes of the struct
 * but the 'struct LinkTable *pNode'
 */
typedef struct DataNode
{
	struct LinkTableNode * pNext; 
	char*   cmd;
 	char*   desc;
 	int     (*handler)();
} tDataNode;

typedef struct LinkTableNode 
{ 
    struct LinkTableNode * pNext; 
} tLinkTableNode; 


typedef struct LinkTable 
{ 
	tLinkTableNode *pHead; 
	tLinkTableNode *pTail; 
	int			SumOfNode; 
/*	pthread_mutex_t mutex;*/ 
} tLinkTable; 

#define SUCCESS 1
#define FAILURE 0
tDataNode * InputYourCmd();

int ShowAllCmd();
/*init all resource that a new menu need*/
int InitNes();

/*find a cmd that you want*/
int MenuStart();

/*add a cmd that you need*/
int AddCmd();

/*delete the cmd that you needn't*/
int DeleteCmd();

