#include"menu_operate.h"
#include<stdio.h>
#include<stdlib.h>

int results[7] = {1,1,1,1,1,};
int Help();
 char *info[5] =
    {
        "InputYourCmd",
        "ShowAllCmd",
        "MenuStart",
        "AddCmd",
        "DeleteCmd"
    }; 
    
 char *info1[2] =
 {
    "is success!",
    "is fail!"
 };

tDataNode dn[2]=
{
    {(tLinkTableNode *)&dn[1],"help","first cmd",Help},
    {NULL,"version","second cmd",NULL}, 
};

tDataNode dn1 = {NULL,NULL,"SUCCESS",NULL};


/* This function is ShowAllCmd()'s teststub*/ 
tLinkTableNode * GetLinkTableHead(tLinkTable * pLinkTable)
{
	return (tLinkTableNode *)&dn[0];
}
/* This function is AddCmd()'s teststub*/
void AddLinkTableNode(tLinkTable * pLinkTable,tLinkTableNode * pLinkTableNode){}

/* This function is AddCmd()'s teststub*/
tLinkTableNode *  CheckCmd_Add(char * cmd,tLinkTable * pLinkTable)
{
	return NULL;
}


/* This function is DeleteCmd()'s teststub*/
tLinkTableNode *  CheckCmd_Delete(char * cmd,tLinkTable * pLinkTable)
{
	return (tLinkTableNode *)&dn[0];
}

/* This function is DeleteCmd()'s teststub*/
void DelLinkTableNode(tLinkTable * pLinkTable,tLinkTableNode * pLinkTableNode){}

/* This function is MenuStart()'s teststub*/
int Help()
{
	printf("I am the cmd ...\n");
}

/* This function is MenuStart()'s teststub*/
tDataNode * FindCmd(char * cmd)
{
	return &dn[0];
}


/* This function is InputYour()'s teststub*/
tDataNode * InitDataNode()
{
	tDataNode * dn = (tDataNode *)malloc(sizeof(tDataNode));
	return dn;
}


/* This function is InitNes()'s teststub*/
void InitLinkTable(){}

/* This function is InitNes()'s teststub*/
void InitCmdList(){}

int AddCmdTest()
{
	int addCmd = AddCmd();
	if(addCmd != SUCCESS)
	{
		 results[3] = 0;
	} 
}

int ShowAllCmdTest()
{
    int showAllCmd = ShowAllCmd();
    if(showAllCmd != SUCCESS)
    {
        results[1] = 0;
    } 
}

int DeleteCmdTest()
{
    int deleteCmd = DeleteCmd();
    if(deleteCmd != SUCCESS)
    {
    	results[4] = 0;
    }	
}

void MenuStartTest()
{
	int menuStar = MenuStart();
	if(menuStar != SUCCESS)
	{
		results[2] = 0;
	}	
}

void InputYourCmdTest()
{
	tDataNode * pdatanode = InputYourCmd();
	if( pdatanode == NULL )
    {
    	results[0] = 0;
    }
}
main()
{
	int i;
	printf("test of InputYourCmd\n\n");
	InputYourCmdTest();
	printf("test of addCmd\n\n");
	 AddCmdTest();
	 printf("test of ShowAllCmd\n\n");
	 ShowAllCmdTest();
	 printf("test of MenuStart\n\n");
	 MenuStart();
	 printf("test of DeleteCmdTest\n\n");
	 DeleteCmdTest();
	 printf("\n\n");
	 printf("print test report:\n\n");
	 for(i = 0;i<5;i++)
	 {
	 	if(results[i] == 0)
	 	{
	 	    printf("%s %s\n",info[i],info1[1]);
	 	}
	 	else
	    {
	    	printf("%s %s\n",info[i],info1[0]);
	    }
	 }
	 
}


