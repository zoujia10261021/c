/**************************************************************************************************/
/* Copyright (C) zoujia, SSE@USTC, 2014-2015                                                      */
/*                                                                                                */
/*  FILE NAME             :  zoujia_menu_main.c                                                   */
/*  PRINCIPAL AUTHOR      :  Zoujia                                                               */
/*  SUBSYSTEM NAME        :  zoujia_menu_main                                                     */
/*  MODULE NAME           :  zoujia_menu_main                                                     */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/12                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zoujia, 2014/09/12
 *
 */
 
 
#include<stdio.h>
#include<stdlib.h>
#include "menu_operate.h"
#include "linktable.h"

extern tLinkTable * pLinkTable;

int Help()
{
    printf("%s %s\n",((tDataNode*)GetLinkTableHead(pLinkTable)) -> cmd,
                     ((tDataNode*)GetLinkTableHead(pLinkTable)) -> desc);
    ShowAllCmd();
    return 0;
}

tDataNode * InitDataNode()
{
    tDataNode *pDataNode;
    pDataNode = (tDataNode*)malloc(sizeof(tDataNode));
    if(pDataNode == NULL)
    {
        exit(0);
    }
    return pDataNode;
}

tLinkTableNode * CheckCmd(char* cmd,tLinkTable* pLinkTable)
{
    tDataNode *p = (tDataNode *)GetLinkTableHead(pLinkTable);
    while(p != NULL)
    {
        if(strcmp(cmd,p->cmd) == 0)
        {
            return (tLinkTableNode*)p;
        }
        p = (tDataNode *)(p->pNext);
    }
    return NULL;
}



tDataNode* FindCmd(char *cmd)
{
    if( pLinkTable -> pHead == NULL || cmd == NULL )
    {
        return NULL;
    }
    tDataNode * pDataNode =(tDataNode *)pLinkTable -> pHead;
    while( pDataNode != NULL )
    {
        if( !strcmp( pDataNode -> cmd, cmd ) )
        {
            return pDataNode;
        }
        pDataNode = (tDataNode *)pDataNode -> pNext;
    }
    return NULL;
}

void InitLinkTable()
{
    pLinkTable = CreateLinkTable(); 
    if(pLinkTable == NULL)
    {
        exit(0);
    }
}

void InitCmdList()
{
    if(1)
    {
        tDataNode * pDataNode = InitDataNode();
        pDataNode->pNext = NULL;
        pDataNode->cmd = "help";
        pDataNode->desc = "This is help menu";
        pDataNode->handler = Help;
        tLinkTableNode* pLinkTableNode = (tLinkTableNode *)pDataNode;
        AddLinkTableNode(pLinkTable,pLinkTableNode); 
    }
    else
    {
        tDataNode pDataNode;
        pDataNode.pNext = NULL;
        pDataNode.cmd = "help";
        pDataNode.desc = "This is help menu";
        pDataNode.handler = Help;
        tLinkTableNode* pLinkTableNode = (tLinkTableNode *)&pDataNode;
        AddLinkTableNode(pLinkTable,pLinkTableNode); 
    }	
}