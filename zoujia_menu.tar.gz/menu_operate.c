/**************************************************************************************************/
/* Copyright (C) zoujia, SSE@USTC, 2014-2015                                                      */
/*                                                                                                */
/*  FILE NAME             :  zoujia_menu_main.c                                                   */
/*  PRINCIPAL AUTHOR      :  Zoujia                                                               */
/*  SUBSYSTEM NAME        :  zoujia_menu_main                                                     */
/*  MODULE NAME           :  zoujia_menu_main                                                     */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/12                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zoujia, 2014/09/12
 *
 */
 
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "menu_operate.h"
#include "linktable.h"
#include "support.h"
 
#define CMD_MAX_LEN 128
#define DESC_MAX_LEN 1200

tLinkTable * pLinkTable = NULL; 

void InitNes()
{
    InitLinkTable();
    InitCmdList();
}

tDataNode * InputYourCmd()
{
	int i;
	tDataNode * pDataNode = InitDataNode();
	pDataNode -> cmd = (char *)malloc(sizeof(char));
    pDataNode->pNext = NULL;
    printf("please input your cmd\n");
    scanf("%s",pDataNode -> cmd);
    while(CheckCmd(pDataNode -> cmd,pLinkTable))
    {
        printf("repeat!please reinput\n");
        scanf("%s",pDataNode -> cmd);
    }
    printf("please input the description of your cmd\n");
    pDataNode -> desc = (char *)malloc(sizeof(char)*DESC_MAX_LEN);
    getchar();
    fgets( pDataNode -> desc,DESC_MAX_LEN,stdin);
    i = strlen(pDataNode -> desc);
    (pDataNode -> desc)[i-1] = '\0';
     pDataNode ->handler = NULL;
    return pDataNode;
    
}

int ShowAllCmd()
{
    printf("cmd list:\n");
    tDataNode *p = (tDataNode *)GetLinkTableHead(pLinkTable);
    while( p != NULL)
    {
        printf("%s %s\n",p -> cmd,p -> desc);
        p = (tDataNode *)(p -> pNext);
    }	
    return 0;
}

/* add client's cmd and smd's description */
int AddCmd()
{
	tLinkTableNode * pLinkTableNode = (tLinkTableNode *)InputYourCmd();
    if(pLinkTableNode == NULL)
    {
        return 0;
    }
    else
    {
        AddLinkTableNode(pLinkTable,pLinkTableNode); 
        printf("SUCESS!\n");
	}
    return 1;
}

/* delete a cmd of yours*/
int DeleteCmd()
{
    char * cmd;
    tLinkTableNode * pLinkTableNode;   
    printf("please input the cmd that you want to delete\n");
    cmd = (char *)malloc(sizeof(char));
    scanf("%s",cmd);
    pLinkTableNode = CheckCmd(cmd,pLinkTable);
    if(pLinkTableNode != NULL)
    {
        DelLinkTableNode(pLinkTable,pLinkTableNode);
        printf("Delete!\n");
        return 1;
    }
    printf("cmd not exist!\n");
    return 0;
}

/*find a cmd*/
int MenuStart()
{
    tDataNode* p;
    char cmd[CMD_MAX_LEN];
    printf("Intput a cmd >");
    scanf("%s", cmd);
    p = FindCmd(cmd);	
    if(p)
    {
        if(p -> handler )
        {
            p -> handler();
        }
        else
        {
            printf("%s %s\n",p -> cmd,p -> desc);
        }
    }
    else
    {
        printf("This is a wrong cmd\n");
    }
 }
 
